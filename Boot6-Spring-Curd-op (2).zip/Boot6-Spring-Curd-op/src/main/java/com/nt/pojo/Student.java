package com.nt.pojo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement(name="Student")
@XmlAccessorType(XmlAccessType.FIELD)
public class Student {
	private Integer id;
	private String name;
	private String password;
	private String email;
	private long phno;
	private boolean active=true;

}
