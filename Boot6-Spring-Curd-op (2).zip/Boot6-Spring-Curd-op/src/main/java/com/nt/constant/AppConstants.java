package com.nt.constant;

public class AppConstants {

	/**
	 * for key of success message
	 */
	public static final String succMsgKey="regsucc";
	/**
	 * for key of fail message
	 */
	public static final String failMsgKey="regfail";
	
	/**
	 * model attribute name
	 */
	public static final String EditAttribute="student";
	/**
	 * logical view name for student registration
	 */
	public static final String viewName="StudentForm";
	
	/**
	 * logical view name for display the data
	 */
	public static final String viewStudentData="ViewAllStudent";
	/**
	 * logical view name for edit the data
	 */
	public static final String editStudentData="EditStudent";
	
	/**
	 * model attribute name
	 */
	public static final String listOfStudents="studentList";
	
}
