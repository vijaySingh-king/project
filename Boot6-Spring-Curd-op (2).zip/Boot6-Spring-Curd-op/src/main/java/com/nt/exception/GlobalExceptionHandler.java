package com.nt.exception;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Controller
@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value=NullPointerException.class)
	public String NullPointerExceptionCustome(Model model) {
	model.addAttribute("errMsg","Internal Problemm Please Try again");
		return "errorPage";
		
	}
	

	@ExceptionHandler(value=NullPointerException.class)
	public String NumberFormateHandle(Model model) {
	model.addAttribute("errMsg","Internal Problemm Please Try again");
		return "errorPage";
		
	}
}
