package com.nt.restController;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nt.entity.StudentEntity;
import com.nt.pojo.Student;
import com.nt.repo.StudentRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;

@RestController
@Api("this is welcome Controller")
public class StudentRestController {

	@Autowired
	private StudentRepository stuRepo;
	
	@GetMapping(value="/getStudents",
			    produces = {
			    		   
			    		   "application/xml",
			    		   "application/json"
			    		   }
	            )
	@ApiOperation("this is user method")
	@ApiResponse(response = Student.class, code = 200, message = "String value")
	public Student getStudentByIdDetails(@RequestParam("id") Integer id){
		Optional<StudentEntity> optentity= stuRepo.findById(id);
		StudentEntity entity=optentity.get();
		Student student=new Student();
		BeanUtils.copyProperties(entity, student);
		return student;
	}
}
