package com.nt.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.nt.Config.AppConfig;
import com.nt.constant.AppConstants;
import com.nt.entity.StudentEntity;
import com.nt.pojo.Student;
import com.nt.repo.StudentRepository;

@Controller
public class StudentController {

	@Autowired
	private AppConfig appconfig;
	
	@Autowired
	private StudentRepository studentRepo;
	
	@RequestMapping(value= {"/","/register"})
	public String formLoad(Model model) {
		Student student=new Student();
		model.addAttribute("student",student);
		return AppConstants.viewName;
		
	}
	
	@RequestMapping(value="/register",method = RequestMethod.POST)
	public String formSave(RedirectAttributes attribute ,@ModelAttribute("student") Student student) {
		StudentEntity entity=new StudentEntity();
		String msg=null;
		System.out.println("student  "+student);
		BeanUtils.copyProperties(student,entity);
		//System.out.println("this is "+appconfig.getMessages().get("regsucc"));
		//System.out.println(student);
		System.out.println("entity  "+entity);
		StudentEntity savedEntity=studentRepo.save(entity);

		
		if (savedEntity.getId()!=null) {
			 msg=entity.getId()+" entity "+appconfig.getMessages().get(AppConstants.succMsgKey);
		}else {
			 msg=appconfig.getMessages().get(AppConstants.failMsgKey);
		}
		attribute.addFlashAttribute("msg",msg);
		return "redirect:/registerstopdblpostreq";
	}
	
	
/*	
  @RequestMapping(value="/viewStudent1",method=RequestMethod.GET)
	public String viewStudentData(Model model) {
		Iterable<StudentEntity> listEntity= studentRepo.findAllAfterSoftDeletion();
		List<Student> listStudent=new ArrayList();
		System.out.println("list Entity :"+listEntity);
		
		  for(StudentEntity entity:listEntity) { 
			  Student student=new Student();
			  BeanUtils.copyProperties(entity,student); 
			  listStudent.add(student);
		  }
		  
		  //System.out.println(student); }
		  model.addAttribute(AppConstants.listOfStudents,listStudent);
		 return  AppConstants.viewStudentData;
	}
	*/ 
	@RequestMapping(value="/viewStudent1",method=RequestMethod.GET)
	public String viewStudentData1(Model model,@RequestParam("pn") Integer currPage) {
		int pageSize=5;
		PageRequest page=PageRequest.of(currPage-1, pageSize);
		
		//Page<StudentEntity> stEntity= studentRepo.findAll(page);
		
		Page<StudentEntity> stEntity= studentRepo.findAllAfterSoftDeletion(page);
		List<StudentEntity> listEntity=stEntity.getContent();
		
	    //total pages
		int tp=stEntity.getTotalPages();
		List<Student> listStudent=new ArrayList();
		for(StudentEntity entity:listEntity) {
			Student student=new Student();
			BeanUtils.copyProperties(entity,student);
			listStudent.add(student);
			//System.out.println(student);
		}
		model.addAttribute(AppConstants.listOfStudents,listStudent);
		model.addAttribute("tp",tp);
		model.addAttribute("cp",currPage);
		return  AppConstants.viewStudentData;
	}
	
	@RequestMapping(value="/getEmails",method = RequestMethod.GET)
	public @ResponseBody List<String> getAllEmails(){
		List<String> entitylist=studentRepo.getAllEmails();
		
		return entitylist;
		
	}
	
	@RequestMapping(value = "/getEmailById")
	public @ResponseBody String getEmailById(@RequestParam("uid") Integer uid) {
		return studentRepo.getEmailById(uid);
	
	}
	
	@RequestMapping(value="/deleteStudent")
	public String deleteDataById(@RequestParam("id") int id) {
		      // studentRepo.deleteById(id);
		        studentRepo.softDeleteById(id);
		       
		return "redirect:/viewStudent1?pn=1";
		
	}
	
    @RequestMapping(value="/editStudent")
	public String editData(Model model,@RequestParam("sid") Integer id) {
		Optional<StudentEntity> entityOptional = studentRepo.findById(id);
		if(entityOptional.isPresent()) {
			StudentEntity entity=entityOptional.get();
			Student student=new Student();
			BeanUtils.copyProperties(entity, student);
			model.addAttribute(AppConstants.EditAttribute, student);
		}
		
		return AppConstants.editStudentData;
	}
    
    
    @RequestMapping(value="/update",method = RequestMethod.POST)
    public String updateData(@ModelAttribute("student") Student student,Model model,@RequestParam("sid") Integer id){
    	StudentEntity entity=new StudentEntity();
    	BeanUtils.copyProperties(student, entity);
    	entity.setId(id);
    	studentRepo.save(entity);
    	
    	model.addAttribute("msg","Student data update Success fully");
    	
    	//return "redirect:/viewStudent";
    	return AppConstants.editStudentData;
    }
	
	@RequestMapping("/registerstopdblpostreq")
	public String fromDblPostingRedirect(@ModelAttribute ("student") Student student,Model model){
		
		System.out.println("fromDblPostingRedirect");
		return AppConstants.viewName;
	}
}
