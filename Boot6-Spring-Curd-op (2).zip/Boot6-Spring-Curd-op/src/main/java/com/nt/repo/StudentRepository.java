package com.nt.repo;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.StudentEntity;

//@Repository
public interface StudentRepository  extends JpaRepository<StudentEntity,Serializable>{

	@Query(value ="select email from StudentEntity")
	public List<String> getAllEmails();
	
	
	@Query(value ="select email from StudentEntity where id=:id")
	public String getEmailById(Integer id);
	
	
	@Query(value ="update StudentEntity e set e.active=0 where e.id=:id")
	@Modifying
	@Transactional
	public void softDeleteById(int id);
	
	
	@Query(value ="select e from StudentEntity e where e.active=true")
	public Page<StudentEntity> findAllAfterSoftDeletion(PageRequest page);
	 
	
	
}
